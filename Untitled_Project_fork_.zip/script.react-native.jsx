import React from 'react';

function App() {
  // Стили для контейнера (зеленый фон)
  const containerStyle = {
    backgroundColor: '#32CD32', // Зеленый цвет травы
    width: '100vw',
    height: '100vh',
    margin: 0,
    padding: 0,
    position: 'relative',
    overflow: 'hidden',
  };

  // Стиль для неба
  const skyStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '70%',
    backgroundColor: '#87CEEB', // Синий цвет неба
    zIndex: 1,
  };

  // Стиль для человека (черный)
  const personStyle = {
    position: 'absolute',
    bottom: '20%',
    left: '50%',
    transform: 'translateX(-50%)',
    width: '40px',
    height: '80px',
    backgroundColor: 'black',
    borderRadius: '5px',
    zIndex: 3,
  };

  // Стиль для рюкзака
  const backpackStyle = {
    position: 'absolute',
    bottom: '20%',
    left: '52%',
    width: '30px',
    height: '50px',
    backgroundColor: '#333',
    borderRadius: '5px',
    zIndex: 2,
  };

  // Стиль для собаки
  const dogStyle = {
    position: 'absolute',
    bottom: '20%',
    left: '40%',
    width: '30px',
    height: '20px',
    backgroundColor: '#8B4513', // Коричневый цвет
    borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
    zIndex: 3,
  };

  // Создаем 4 дерева на разных позициях
  const tree1Style = {
    position: 'absolute',
    bottom: '20%',
    left: '10%',
    width: '20px',
    height: '60px',
    backgroundColor: '#8B4513',
    zIndex: 2,
  };
  
  const tree1TopStyle = {
    position: 'absolute',
    bottom: '65%',
    left: '5%',
    width: '60px',
    height: '80px',
    backgroundColor: '#228B22',
    borderRadius: '50%',
    zIndex: 2,
  };

  const tree2Style = {
    position: 'absolute',
    bottom: '20%',
    left: '25%',
    width: '20px',
    height: '70px',
    backgroundColor: '#8B4513',
    zIndex: 2,
  };
  
  const tree2TopStyle = {
    position: 'absolute',
    bottom: '70%',
    left: '20%',
    width: '70px',
    height: '90px',
    backgroundColor: '#228B22',
    borderRadius: '50%',
    zIndex: 2,
  };

  const tree3Style = {
    position: 'absolute',
    bottom: '20%',
    left: '70%',
    width: '20px',
    height: '65px',
    backgroundColor: '#8B4513',
    zIndex: 2,
  };
  
  const tree3TopStyle = {
    position: 'absolute',
    bottom: '65%',
    left: '65%',
    width: '65px',
    height: '85px',
    backgroundColor: '#228B22',
    borderRadius: '50%',
    zIndex: 2,
  };

  const tree4Style = {
    position: 'absolute',
    bottom: '20%',
    left: '85%',
    width: '20px',
    height: '55px',
    backgroundColor: '#8B4513',
    zIndex: 2,
  };
  
  const tree4TopStyle = {
    position: 'absolute',
    bottom: '60%',
    left: '80%',
    width: '55px',
    height: '75px',
    backgroundColor: '#228B22',
    borderRadius: '50%',
    zIndex: 2,
  };

  return (
    <div style={containerStyle}>
      <div style={skyStyle}></div>
      
      {/* Деревья на фоне */}
      <div style={tree1Style}></div>
      <div style={tree1TopStyle}></div>
      
      <div style={tree2Style}></div>
      <div style={tree2TopStyle}></div>
      
      <div style={tree3Style}></div>
      <div style={tree3TopStyle}></div>
      
      <div style={tree4Style}></div>
      <div style={tree4TopStyle}></div>
      
      {/* Человек и рюкзак */}
      <div style={backpackStyle}></div>
      <div style={personStyle}></div>
      
      {/* Собака */}
      <div style={dogStyle}></div>
    </div>
  );
}

export default App;